import asyncio
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties

from config import BOT_TOKEN
from database.db import create_tables

from handlers import start, booking, prices, portfolio, subscription, admin
from services.scheduler import scheduler


async def main():

    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode="HTML")
    )

    dp = Dispatcher()

    dp.include_router(start.router)
    dp.include_router(booking.router)
    dp.include_router(prices.router)
    dp.include_router(portfolio.router)
    dp.include_router(subscription.router)
    dp.include_router(admin.router)

    await create_tables()

    scheduler.start()

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())