from aiogram import Router
from aiogram.types import Message
from config import ADMIN_ID

router = Router()


@router.message()
async def admin_panel(message: Message):

    if message.from_user.id != ADMIN_ID:
        return

    await message.answer("""
Админ панель

/add_day
/add_slot
/delete_slot
/view_day
/close_day
""")