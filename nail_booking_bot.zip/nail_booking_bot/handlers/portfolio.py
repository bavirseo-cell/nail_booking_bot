from aiogram import Router, F
from aiogram.types import CallbackQuery
from keyboards.user_kb import portfolio_kb

router = Router()


@router.callback_query(F.data == "portfolio")
async def portfolio(callback: CallbackQuery):

    await callback.message.answer(
        "Посмотрите наши работы:",
        reply_markup=portfolio_kb()
    )