from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from states.booking_states import BookingState

router = Router()


@router.callback_query(F.data == "book")
async def choose_date(callback: CallbackQuery, state: FSMContext):

    await callback.message.answer("Выберите дату:")
    await state.set_state(BookingState.choosing_date)


@router.message(BookingState.enter_name)
async def name(message: Message, state: FSMContext):

    await state.update_data(name=message.text)

    await message.answer("Введите номер телефона:")

    await state.set_state(BookingState.enter_phone)


@router.message(BookingState.enter_phone)
async def phone(message: Message, state: FSMContext):

    data = await state.get_data()

    await message.answer(
        f"""
<b>Запись подтверждена</b>

Имя: {data['name']}
Телефон: {message.text}
""",
        parse_mode="HTML"
    )

    await state.clear()