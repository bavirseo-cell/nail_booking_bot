from aiogram import Router, F
from aiogram.types import CallbackQuery

router = Router()


@router.callback_query(F.data == "prices")
async def prices(callback: CallbackQuery):

    text = """
<b>Прайс:</b>

Френч — 1000₽
Квадрат — 500₽
"""

    await callback.message.answer(text, parse_mode="HTML")