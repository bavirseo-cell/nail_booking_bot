from aiogram import Router
from aiogram.types import CallbackQuery
from config import CHANNEL_ID, CHANNEL_LINK
from keyboards.user_kb import subscribe_kb

router = Router()


async def check_subscription(bot, user_id):
    member = await bot.get_chat_member(CHANNEL_ID, user_id)
    return member.status in ["member", "administrator", "creator"]


@router.callback_query(lambda c: c.data == "check_sub")
async def check(callback: CallbackQuery):

    ok = await check_subscription(callback.bot, callback.from_user.id)

    if ok:
        await callback.message.answer("✅ Подписка подтверждена")
    else:
        await callback.message.answer(
            "Для записи необходимо подписаться на канал",
            reply_markup=subscribe_kb(CHANNEL_LINK)
        )