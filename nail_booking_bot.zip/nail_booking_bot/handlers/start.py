from aiogram import Router
from aiogram.types import Message
from aiogram.filters import CommandStart
from keyboards.user_kb import main_menu

router = Router()


@router.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "<b>Добро пожаловать!</b>\n\nВыберите действие:",
        reply_markup=main_menu()
    )