from aiogram.fsm.state import StatesGroup, State


class BookingState(StatesGroup):
    choosing_date = State()
    choosing_time = State()
    enter_name = State()
    enter_phone = State()