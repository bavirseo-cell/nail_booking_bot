from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def main_menu():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📅 Записаться", callback_data="book")],
            [InlineKeyboardButton(text="💰 Прайсы", callback_data="prices")],
            [InlineKeyboardButton(text="📷 Портфолио", callback_data="portfolio")]
        ]
    )


def portfolio_kb():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(
                text="Смотреть портфолио",
                url="https://ru.pinterest.com/crystalwithluv/_created/"
            )]
        ]
    )


def subscribe_kb(link):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Подписаться", url=link)],
            [InlineKeyboardButton(text="Проверить подписку", callback_data="check_sub")]
        ]
    )