from datetime import datetime, timedelta
from services.scheduler import scheduler


async def send_reminder(bot, user_id, time):

    text = f"""
Напоминаем, что вы записаны на наращивание ресниц завтра в {time}.
Ждём вас ❤️
"""

    await bot.send_message(user_id, text)


def schedule_reminder(bot, user_id, date, time, job_id):

    visit = datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M")

    remind_time = visit - timedelta(hours=24)

    if remind_time > datetime.now():

        scheduler.add_job(
            send_reminder,
            "date",
            run_date=remind_time,
            args=[bot, user_id, time],
            id=job_id
        )